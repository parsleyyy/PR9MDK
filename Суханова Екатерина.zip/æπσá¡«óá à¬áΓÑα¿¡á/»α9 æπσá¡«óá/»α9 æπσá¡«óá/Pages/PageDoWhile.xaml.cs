﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace пр9_Суханова.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDoWhile.xaml
    /// </summary>
    public partial class PageDoWhile : Page
    {
        public PageDoWhile()
        {
            InitializeComponent();
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            clsFrame.frmObject.Navigate(new PageFor());
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            double x0 = Convert.ToDouble(txtX0.Text);
            double xk = Convert.ToDouble(txtXK.Text);
            double dx = Convert.ToDouble(txtDX.Text);
            double a = Convert.ToDouble(txtA.Text);


            double x = x0;

            do
            {
                double y = a * Math.Abs(Math.Pow(x, 5 / 2)) + Math.Cos(Math.Sqrt(Math.Exp(x)));
                lstTable.Items.Add($"x={x}  y={y}");
                x = x + dx;
            }
            while (x <= (xk + dx / 2));
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            clsFrame.frmObject.Navigate(new PageWhile());
        }
    }
}
